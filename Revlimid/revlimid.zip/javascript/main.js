function next_slide(slide) {
	window.location.href=slide;
    }



    

